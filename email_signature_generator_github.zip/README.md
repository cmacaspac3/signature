# Email Signature Generator

Deployed with GitHub Pages.
Open `index.html` locally or enable GitHub Pages to host it live.